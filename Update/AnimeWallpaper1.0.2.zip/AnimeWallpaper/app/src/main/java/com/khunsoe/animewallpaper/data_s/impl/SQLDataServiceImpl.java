package com.khunsoe.animewallpaper.data_s.impl;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.khunsoe.animewallpaper.data_s.DataService;
import com.khunsoe.animewallpaper.data_s.SQLCategories;
import com.khunsoe.animewallpaper.utils.SQLFav;

public class SQLDataServiceImpl extends DataService {

    final InternalSQLWallpapers sqlWallpapers;
    final Context context;

    public SQLDataServiceImpl(Context context, SQLCategories sqlCategories, SQLFav sqlFav) {
        super(sqlCategories, sqlFav);
        this.context = context;
        this.sqlWallpapers = new InternalSQLWallpapers(context);
        InitSQL.applyWallpapers(context, sqlWallpapers, sqlFav);
    }

    @Override
    public void setupCategories(OnCategoriesLoaded onCategoriesLoaded) {
        InitSQL.applyCategories(context, sqlWallpapers, sqlCategories);
        onCategoriesLoaded.onCategoriesLoaded();
    }

    @Override
    public void getWallpapers(int page, DataService.QueryType type, String string, OnWallpapersLoaded onWallpapersLoaded) {
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            switch (type) {
                case NONE:
                default:
                    onWallpapersLoaded.onWallpapersLoaded(sqlWallpapers.getWallpapers(page, InternalSQLWallpapers.QueryType.NONE, string));
                    break;
                case CATEGORY:
                    onWallpapersLoaded.onWallpapersLoaded(sqlWallpapers.getWallpapers(page, InternalSQLWallpapers.QueryType.CATEGORY, string));
                    break;
                case SEARCH:
                    onWallpapersLoaded.onWallpapersLoaded(sqlWallpapers.getWallpapers(page, InternalSQLWallpapers.QueryType.SEARCH, string));
                    break;
                case FAVORITE:
                    onWallpapersLoaded.onWallpapersLoaded(sqlFav.getWallpapers(page));
                    break;
            }
        }, type == QueryType.FAVORITE ? 200 : 800);

    }
}
